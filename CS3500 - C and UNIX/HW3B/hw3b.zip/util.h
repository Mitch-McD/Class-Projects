#ifndef _UTIL_H
#define _UTIL_H

#define N 8

typedef struct _Matrix {
    int element[N][N];
} Matrix;

void PrintMatrix(Matrix a);

#endif

